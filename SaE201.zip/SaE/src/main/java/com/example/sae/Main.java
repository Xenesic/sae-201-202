package com.example.sae;

import javafx.application.Application;
import javafx.stage.Stage;
import vue.MainWindow;

public class Main extends Application {
    @Override
    public void start(Stage primaryStage) {
        System.out.println("Démarrage de l'application...");
        primaryStage.setMaximized(true);
        new MainWindow(primaryStage);
        primaryStage.setOnShown(e -> {
            System.out.println("Fenêtre affichée, forçage du rafraîchissement");
            primaryStage.setWidth(primaryStage.getWidth() + 1);
            primaryStage.setWidth(primaryStage.getWidth() - 1);
        });
    }

    public static void main(String[] args) {
        launch(args);
    }
}