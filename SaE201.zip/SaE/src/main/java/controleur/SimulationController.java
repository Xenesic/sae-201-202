package controleur;

import modele.*;
import vue.*;

/**
 * Contrôleur pour la simulation du jeu.
 * Gère les interactions utilisateur pendant la simulation.
 */
public class SimulationController {
    private MainWindow mainWindow;
    private Simulation simulation;
    private Direction directionMouton;
    private int distanceMouton;
    private Direction directionLoup;
    private int distanceLoup; // Nouvelle variable pour la distance du loup
    private boolean mouvementMoutonEffectue;
    private boolean mouvementLoupEffectue;

    /**
     * Constructeur du contrôleur de simulation.
     * @param mainWindow La fenêtre principale de l'application
     */
    public SimulationController(MainWindow mainWindow) {
        this.mainWindow = mainWindow;
        this.mouvementMoutonEffectue = false;
        this.mouvementLoupEffectue = false;
        this.distanceMouton = 0; // Valeur par défaut
        this.distanceLoup = 0;   // Valeur par défaut
    }

    /**
     * Définit la simulation à contrôler.
     * @param simulation La simulation à contrôler
     */
    public void setSimulation(Simulation simulation) {
        this.simulation = simulation;
    }

    /**
     * Méthode originale pour déplacer le mouton (pour la compatibilité).
     * @param direction La direction du déplacement
     */
    public void deplacerMouton(Direction direction) {
        // Utiliser la vitesse maximale du mouton
        if (simulation != null) {
            deplacerMouton(direction, simulation.getMouton().getVitesse());
        } else {
            deplacerMouton(direction, 2); // Valeur par défaut si simulation est null
        }
    }

    /**
     * Méthode pour déplacer le mouton avec une distance spécifiée.
     * @param direction La direction du déplacement
     * @param distance La distance à parcourir
     */
    public void deplacerMouton(Direction direction, int distance) {
        if (simulation == null || simulation.estTerminee() || mouvementMoutonEffectue) {
            return;
        }

        this.directionMouton = direction;
        this.distanceMouton = distance;  // Stocker la distance choisie
        this.mouvementMoutonEffectue = true;

        verifierFinTour();
    }

    /**
     * Méthode originale pour déplacer le loup (pour la compatibilité).
     * @param direction La direction du déplacement
     */
    public void deplacerLoup(Direction direction) {
        // Utiliser la vitesse maximale du loup
        if (simulation != null) {
            deplacerLoup(direction, simulation.getLoup().getVitesse());
        } else {
            deplacerLoup(direction, 3); // Valeur par défaut si simulation est null
        }
    }

    /**
     * Méthode pour déplacer le loup avec une distance spécifiée.
     * @param direction La direction du déplacement
     * @param distance La distance à parcourir
     */
    public void deplacerLoup(Direction direction, int distance) {
        if (simulation == null || simulation.estTerminee() || mouvementLoupEffectue) {
            return;
        }

        this.directionLoup = direction;
        this.distanceLoup = distance;  // Stocker la distance choisie
        this.mouvementLoupEffectue = true;

        verifierFinTour();
    }

    /**
     * Vérifie si le tour est terminé et joue le tour si c'est le cas.
     */
    private void verifierFinTour() {
        if (mouvementMoutonEffectue && mouvementLoupEffectue) {
            // Appeler jouerTour avec les distances spécifiées pour le mouton et le loup
            simulation.jouerTour(directionMouton, distanceMouton, directionLoup, distanceLoup);
            mainWindow.getSimulationPanel().mettreAJourInfos(simulation);

            mouvementMoutonEffectue = false;
            mouvementLoupEffectue = false;
        }
    }
}