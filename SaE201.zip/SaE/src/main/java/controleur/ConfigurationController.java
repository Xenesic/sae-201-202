package controleur;

import modele.*;
import vue.*;
import java.io.*;
import javafx.scene.control.Alert;

/**
 * Contrôleur pour la configuration du labyrinthe.
 * Gère les interactions utilisateur dans la phase de configuration.
 */
public class ConfigurationController {
    private MainWindow mainWindow;
    private Labyrinthe labyrinthe;
    private Position positionMouton;
    private Position positionLoup;
    private TypeCase typeCaseSelectionnee;
    private Mode modeActuel;

    /**
     * Modes possibles pour la configuration.
     */
    private enum Mode {
        AUCUN,
        CHOISIR_SORTIE,
        PLACER_ELEMENT,
        PLACER_MOUTON,
        PLACER_LOUP
    }

    /**
     * Constructeur du contrôleur de configuration.
     * @param mainWindow La fenêtre principale de l'application
     */
    public ConfigurationController(MainWindow mainWindow) {
        this.mainWindow = mainWindow;
        this.modeActuel = Mode.AUCUN;

        // Initialiser le gestionnaire de clic de cellule
        if (mainWindow.getLabyrinthCanvas() != null) {
            initialiserGestionnaireClic();
        }
    }

    /**
     * Initialise le gestionnaire de clic sur les cellules du labyrinthe.
     */
    private void initialiserGestionnaireClic() {
        mainWindow.getLabyrinthCanvas().setOnCellClicked((x, y) -> {
            if (labyrinthe == null) return;

            if (x < 0 || x >= labyrinthe.getLargeur() || y < 0 || y >= labyrinthe.getHauteur()) {
                return;
            }

            switch (modeActuel) {
                case CHOISIR_SORTIE:
                    if ((x == 0 || x == labyrinthe.getLargeur() - 1 || y == 0 || y == labyrinthe.getHauteur() - 1) &&
                            labyrinthe.getTypeCase(x, y) == TypeCase.ROCHER) {
                        System.out.println("Définition de la sortie à la position " + x + "," + y);
                        labyrinthe.setTypeCase(x, y, TypeCase.SORTIE);
                        System.out.println("Nouvelle sortie : " + labyrinthe.getPositionSortie());
                        mainWindow.getConfigPanel().verrouillerCarteBtn.setDisable(false);
                    } else {
                        System.out.println("Impossible de définir la sortie à la position " + x + "," + y);
                        System.out.println("Type de case actuel : " + labyrinthe.getTypeCase(x, y));

                        // Afficher une alerte pour guider l'utilisateur
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Information");
                        alert.setHeaderText("Position de sortie invalide");
                        alert.setContentText("La sortie doit être placée sur un rocher au bord du labyrinthe.");
                        alert.showAndWait();
                    }
                    break;

                case PLACER_ELEMENT:
                    // Vérifier si la case est une sortie - si oui, ne pas permettre le placement
                    if (labyrinthe.getTypeCase(x, y) == TypeCase.SORTIE) {
                        System.out.println("Impossible de placer un élément sur la sortie");

                        // Afficher une alerte pour informer l'utilisateur
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setTitle("Action impossible");
                        alert.setHeaderText("Placement invalide");
                        alert.setContentText("Impossible de placer un élément sur la sortie du labyrinthe.");
                        alert.showAndWait();
                        return;
                    }

                    if (!(x == 0 && y == 0) && !(x == labyrinthe.getLargeur() - 1 && y == labyrinthe.getHauteur() - 1)) {
                        System.out.println("Placement d'un élément " + typeCaseSelectionnee + " à la position " + x + "," + y);
                        labyrinthe.setTypeCase(x, y, typeCaseSelectionnee);
                    }
                    break;

                case PLACER_MOUTON:
                    // Vérifier si la case est une sortie - si oui, ne pas permettre le placement
                    if (labyrinthe.getTypeCase(x, y) == TypeCase.SORTIE) {
                        System.out.println("Impossible de placer le mouton sur la sortie");

                        // Afficher une alerte pour informer l'utilisateur
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setTitle("Action impossible");
                        alert.setHeaderText("Placement invalide");
                        alert.setContentText("Impossible de placer le mouton sur la sortie du labyrinthe.");
                        alert.showAndWait();
                        return;
                    }

                    if (labyrinthe.getTypeCase(x, y) != TypeCase.ROCHER) {
                        System.out.println("Placement du mouton à la position " + x + "," + y);
                        positionMouton = new Position(x, y);
                        mainWindow.getLabyrinthCanvas().setPositionMoutonTemp(positionMouton);
                        verifierSiPretALancer();
                    }
                    break;

                case PLACER_LOUP:
                    // Vérifier si la case est une sortie - si oui, ne pas permettre le placement
                    if (labyrinthe.getTypeCase(x, y) == TypeCase.SORTIE) {
                        System.out.println("Impossible de placer le loup sur la sortie");

                        // Afficher une alerte pour informer l'utilisateur
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setTitle("Action impossible");
                        alert.setHeaderText("Placement invalide");
                        alert.setContentText("Impossible de placer le loup sur la sortie du labyrinthe.");
                        alert.showAndWait();
                        return;
                    }

                    if (labyrinthe.getTypeCase(x, y) != TypeCase.ROCHER) {
                        System.out.println("Placement du loup à la position " + x + "," + y);
                        positionLoup = new Position(x, y);
                        mainWindow.getLabyrinthCanvas().setPositionLoupTemp(positionLoup);
                        verifierSiPretALancer();
                    }
                    break;

                default:
                    break;
            }

            mainWindow.getLabyrinthCanvas().redraw();
        });
    }

    /**
     * Vérifie si on peut lancer la simulation.
     * Active le bouton de lancement si le mouton et le loup sont placés.
     */
    private void verifierSiPretALancer() {
        if (positionMouton != null && positionLoup != null) {
            mainWindow.getConfigPanel().activerLancerSimulation();
        }
    }

    /**
     * Crée un nouveau labyrinthe avec les dimensions spécifiées.
     * @param hauteur Hauteur du labyrinthe
     * @param largeur Largeur du labyrinthe
     */
    public void creerLabyrinthe(int hauteur, int largeur) {
        System.out.println("Création d'un labyrinthe de " + hauteur + "x" + largeur);
        labyrinthe = new Labyrinthe(hauteur, largeur);

        LabyrinthCanvas canvas = new LabyrinthCanvas(null);
        canvas.setLabyrinthe(labyrinthe);

        // Afficher les dimensions du canvas avant de le définir
        System.out.println("Dimensions du nouveau canvas : " + canvas.getWidth() + "x" + canvas.getHeight());

        mainWindow.setLabyrinthCanvas(canvas);
        initialiserGestionnaireClic();

        // Réinitialiser les positions
        positionMouton = null;
        positionLoup = null;
    }

    /**
     * Active le mode de choix de la sortie.
     */
    public void setModeChoisirSortie() {
        modeActuel = Mode.CHOISIR_SORTIE;
        System.out.println("Mode actuel : CHOISIR_SORTIE");
        // Effacer les prévisualisations temporaires
        mainWindow.getLabyrinthCanvas().clearPositionsTemp();
    }

    /**
     * Active le mode de placement d'éléments.
     * @param typeCase Le type de case à placer
     */
    public void setModePlacerElement(TypeCase typeCase) {
        modeActuel = Mode.PLACER_ELEMENT;
        typeCaseSelectionnee = typeCase;
        System.out.println("Mode actuel : PLACER_ELEMENT (" + typeCase + ")");
        // Effacer les prévisualisations temporaires
        mainWindow.getLabyrinthCanvas().clearPositionsTemp();
    }

    /**
     * Active le mode de placement du mouton.
     */
    public void setModePlacerMouton() {
        modeActuel = Mode.PLACER_MOUTON;
        System.out.println("Mode actuel : PLACER_MOUTON");
        // Afficher le message de guidage
        System.out.println("Cliquez sur le labyrinthe pour placer le mouton");
    }

    /**
     * Active le mode de placement du loup.
     */
    public void setModePlacerLoup() {
        modeActuel = Mode.PLACER_LOUP;
        System.out.println("Mode actuel : PLACER_LOUP");
        // Afficher le message de guidage
        System.out.println("Cliquez sur le labyrinthe pour placer le loup");
    }

    /**
     * Verrouille la carte du labyrinthe après configuration.
     * Vérifie que la sortie est définie et qu'elle est atteignable depuis toutes les cases intérieures.
     * @return true si la carte est valide et a été verrouillée, false sinon
     */
    public boolean verrouillerCarte() {
        if (labyrinthe.getPositionSortie() == null) {
            System.out.println("Impossible de verrouiller la carte : pas de sortie définie");

            // Afficher une alerte pour guider l'utilisateur
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText("Sortie non définie");
            alert.setContentText("Vous devez définir une sortie avant de verrouiller la carte.");
            alert.showAndWait();

            return false;
        }

        // Vérifier que la sortie est atteignable depuis au moins une case intérieure
        boolean sortieAtteignable = false;

        // Parcourir toutes les cases intérieures du labyrinthe
        for (int y = 1; y < labyrinthe.getHauteur() - 1; y++) {
            for (int x = 1; x < labyrinthe.getLargeur() - 1; x++) {
                // Vérifier uniquement les cases qui ne sont pas des rochers
                if (labyrinthe.getTypeCase(x, y) != TypeCase.ROCHER) {
                    Position positionTest = new Position(x, y);
                    if (labyrinthe.estSortieAtteignable(positionTest)) {
                        sortieAtteignable = true;
                        break;
                    }
                }
            }
            if (sortieAtteignable) break;
        }

        if (!sortieAtteignable) {
            System.out.println("Impossible de verrouiller la carte : la sortie n'est pas atteignable");

            // Afficher une alerte pour guider l'utilisateur
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText("Sortie inaccessible");
            alert.setContentText("La sortie n'est pas atteignable depuis l'intérieur du labyrinthe. Vérifiez qu'il n'y a pas de rochers bloquant tous les chemins vers la sortie.");
            alert.showAndWait();

            return false;
        }

        System.out.println("Carte verrouillée avec succès. Sortie à : " + labyrinthe.getPositionSortie());
        return true;
    }

    /**
     * Sauvegarde le labyrinthe dans un fichier.
     * @param fichier Chemin du fichier
     * @throws IOException Si une erreur survient lors de la sauvegarde
     */
    public void sauvegarderLabyrinthe(String fichier) throws IOException {
        System.out.println("Sauvegarde du labyrinthe dans le fichier : " + fichier);
        labyrinthe.sauvegarder(fichier);
        System.out.println("Labyrinthe sauvegardé avec succès");
    }

    /**
     * Charge un labyrinthe depuis un fichier.
     * @param fichier Chemin du fichier
     * @throws IOException Si une erreur survient lors du chargement
     * @throws ClassNotFoundException Si la classe du labyrinthe n'est pas trouvée
     */
    public void chargerLabyrinthe(String fichier) throws IOException, ClassNotFoundException {
        System.out.println("Chargement du labyrinthe depuis le fichier : " + fichier);
        labyrinthe = Labyrinthe.charger(fichier);
        System.out.println("Labyrinthe chargé avec succès");

        if (labyrinthe.getPositionSortie() != null) {
            System.out.println("Sortie chargée à la position : " + labyrinthe.getPositionSortie());
        } else {
            System.out.println("Attention : aucune sortie définie dans le labyrinthe chargé");
        }

        LabyrinthCanvas canvas = new LabyrinthCanvas(null);
        canvas.setLabyrinthe(labyrinthe);
        mainWindow.setLabyrinthCanvas(canvas);

        initialiserGestionnaireClic();

        // Réinitialiser les positions
        positionMouton = null;
        positionLoup = null;
    }

    /**
     * Lance la simulation avec les paramètres actuels.
     */
    public void lancerSimulation() {
        if (positionMouton == null || positionLoup == null) {
            System.out.println("Impossible de lancer la simulation : positions des animaux non définies");
            return;
        }

        System.out.println("Lancement de la simulation");
        System.out.println("Position du mouton : " + positionMouton);
        System.out.println("Position du loup : " + positionLoup);

        Simulation simulation = new Simulation(labyrinthe, positionMouton, positionLoup);

        LabyrinthCanvas canvas = new LabyrinthCanvas(simulation);
        mainWindow.getSimulationPanel().setLabyrinthCanvas(canvas);
        mainWindow.getSimulationPanel().mettreAJourInfos(simulation);
        mainWindow.getSimulationPanel().activerBoutons();
        mainWindow.basculerVersSimulation();

        SimulationController simulationController = mainWindow.getSimulationPanel().getController();
        simulationController.setSimulation(simulation);

        System.out.println("Simulation lancée avec succès");
    }
}