package vue;

import controleur.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import modele.*;

/**
 * Panel pour la simulation du jeu.
 * Affiche le labyrinthe et les contrôles pour déplacer le mouton et le loup.
 */
public class SimulationPanel extends BorderPane {
    private Button hautBtn;
    private Button basBtn;
    private Button gaucheBtn;
    private Button droiteBtn;
    private ComboBox<Integer> distanceMoutonCombo;
    private ComboBox<Integer> distanceLoupCombo; // Nouveau ComboBox pour le loup
    private Label infoTour;
    private Label infoMouton;
    private Label infoLoup;
    private Label resultat;
    private GridPane commandesMouton;
    private GridPane commandesLoup;
    private VBox infoPanel;
    private LabyrinthCanvas labyrinthCanvas;

    private SimulationController controller;

    /**
     * Constructeur du panel de simulation.
     * @param controller Le contrôleur de simulation
     */
    public SimulationPanel(SimulationController controller) {
        this.controller = controller;
        initialiserComposants();
    }

    /**
     * Initialise tous les composants de l'interface.
     */
    private void initialiserComposants() {
        setPadding(new Insets(10));

        // Panel d'informations
        infoPanel = new VBox(10);
        infoPanel.setPadding(new Insets(10));
        infoPanel.setAlignment(Pos.CENTER_LEFT);
        infoPanel.setPrefWidth(200); // Largeur fixe pour le panneau d'infos

        infoTour = new Label("Tour: 0");
        infoMouton = new Label("Mouton: Vitesse max 2");
        infoLoup = new Label("Loup: Vitesse 3");

        // Résultat avec style pour qu'il soit plus visible
        resultat = new Label("");
        resultat.setFont(Font.font("System", FontWeight.BOLD, 14));
        resultat.setWrapText(true);
        resultat.setMaxWidth(180);
        resultat.setPadding(new Insets(10));
        resultat.setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, new CornerRadii(5), Insets.EMPTY)));
        resultat.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(1))));
        resultat.setVisible(false); // Caché par défaut, apparaîtra lorsque la simulation est terminée

        infoPanel.getChildren().addAll(infoTour, infoMouton, infoLoup, resultat);

        // Créer un conteneur pour le labyrinthe
        StackPane canvasContainer = new StackPane();
        canvasContainer.setAlignment(Pos.CENTER);

        // Créer un panneau pour les commandes et les infos à gauche
        VBox leftPanel = new VBox(20);
        leftPanel.setPadding(new Insets(10));
        leftPanel.setAlignment(Pos.TOP_CENTER);
        leftPanel.setPrefWidth(200); // Largeur fixe pour le panneau de gauche

        // Commandes pour le mouton
        VBox moutonPanel = new VBox(10);
        moutonPanel.setPadding(new Insets(10));
        moutonPanel.setAlignment(Pos.CENTER);
        moutonPanel.getStyleClass().add("control-panel");

        Label moutonLabel = new Label("Mouton");
        moutonLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 16px;");
        moutonLabel.setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, new CornerRadii(5), Insets.EMPTY)));
        moutonLabel.setPadding(new Insets(5, 10, 5, 10));
        moutonLabel.setMaxWidth(Double.MAX_VALUE);

        commandesMouton = new GridPane();
        commandesMouton.setHgap(5);
        commandesMouton.setVgap(5);
        commandesMouton.setPadding(new Insets(5));
        commandesMouton.setAlignment(Pos.CENTER);

        hautBtn = new Button("↑");
        basBtn = new Button("↓");
        gaucheBtn = new Button("←");
        droiteBtn = new Button("→");

        // S'assurer que les boutons ont une taille minimale
        hautBtn.setMinSize(40, 40);
        basBtn.setMinSize(40, 40);
        gaucheBtn.setMinSize(40, 40);
        droiteBtn.setMinSize(40, 40);

        commandesMouton.add(new Label(""), 0, 0);
        commandesMouton.add(hautBtn, 1, 0);
        commandesMouton.add(new Label(""), 2, 0);
        commandesMouton.add(gaucheBtn, 0, 1);
        commandesMouton.add(new Label(""), 1, 1);
        commandesMouton.add(droiteBtn, 2, 1);
        commandesMouton.add(new Label(""), 0, 2);
        commandesMouton.add(basBtn, 1, 2);
        commandesMouton.add(new Label(""), 2, 2);

        // Contrôle de distance pour le mouton
        HBox distanceMoutonBox = new HBox(5);
        distanceMoutonBox.setAlignment(Pos.CENTER);
        Label distanceMoutonLabel = new Label("Distance:");
        distanceMoutonCombo = new ComboBox<>();
        distanceMoutonCombo.getItems().addAll(0, 1, 2);
        distanceMoutonCombo.setValue(2);
        distanceMoutonCombo.setPrefWidth(80);
        distanceMoutonBox.getChildren().addAll(distanceMoutonLabel, distanceMoutonCombo);

        moutonPanel.getChildren().addAll(moutonLabel, commandesMouton, distanceMoutonBox);

        // Commandes pour le loup
        VBox loupPanel = new VBox(10);
        loupPanel.setPadding(new Insets(10));
        loupPanel.setAlignment(Pos.CENTER);
        loupPanel.getStyleClass().add("control-panel");

        Label loupLabel = new Label("Loup");
        loupLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 16px;");
        loupLabel.setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, new CornerRadii(5), Insets.EMPTY)));
        loupLabel.setPadding(new Insets(5, 10, 5, 10));
        loupLabel.setMaxWidth(Double.MAX_VALUE);

        commandesLoup = new GridPane();
        commandesLoup.setHgap(5);
        commandesLoup.setVgap(5);
        commandesLoup.setPadding(new Insets(5));
        commandesLoup.setAlignment(Pos.CENTER);

        Button hautLoupBtn = new Button("↑");
        Button basLoupBtn = new Button("↓");
        Button gaucheLoupBtn = new Button("←");
        Button droiteLoupBtn = new Button("→");

        // S'assurer que les boutons ont une taille minimale
        hautLoupBtn.setMinSize(40, 40);
        basLoupBtn.setMinSize(40, 40);
        gaucheLoupBtn.setMinSize(40, 40);
        droiteLoupBtn.setMinSize(40, 40);

        commandesLoup.add(new Label(""), 0, 0);
        commandesLoup.add(hautLoupBtn, 1, 0);
        commandesLoup.add(new Label(""), 2, 0);
        commandesLoup.add(gaucheLoupBtn, 0, 1);
        commandesLoup.add(new Label(""), 1, 1);
        commandesLoup.add(droiteLoupBtn, 2, 1);
        commandesLoup.add(new Label(""), 0, 2);
        commandesLoup.add(basLoupBtn, 1, 2);
        commandesLoup.add(new Label(""), 2, 2);

        // Contrôle de distance pour le loup (nouveau)
        HBox distanceLoupBox = new HBox(5);
        distanceLoupBox.setAlignment(Pos.CENTER);
        Label distanceLoupLabel = new Label("Distance:");
        distanceLoupCombo = new ComboBox<>();
        distanceLoupCombo.getItems().addAll(0, 1, 2, 3);
        distanceLoupCombo.setValue(3);
        distanceLoupCombo.setPrefWidth(80);
        distanceLoupBox.getChildren().addAll(distanceLoupLabel, distanceLoupCombo);

        loupPanel.getChildren().addAll(loupLabel, commandesLoup, distanceLoupBox);

        // Ajouter les panneaux des commandes au panneau de gauche
        leftPanel.getChildren().addAll(infoPanel, moutonPanel, loupPanel);

        // Disposition des éléments dans la fenêtre
        setLeft(leftPanel);      // Panneau de commandes à gauche
        setCenter(canvasContainer); // Canvas du labyrinthe au centre/droite

        // Ajouter les écouteurs d'événements pour le mouton
        hautBtn.setOnAction(e -> controller.deplacerMouton(Direction.HAUT, distanceMoutonCombo.getValue()));
        basBtn.setOnAction(e -> controller.deplacerMouton(Direction.BAS, distanceMoutonCombo.getValue()));
        gaucheBtn.setOnAction(e -> controller.deplacerMouton(Direction.GAUCHE, distanceMoutonCombo.getValue()));
        droiteBtn.setOnAction(e -> controller.deplacerMouton(Direction.DROITE, distanceMoutonCombo.getValue()));

        // Ajouter les écouteurs d'événements pour le loup (modifiés pour prendre en compte la distance)
        hautLoupBtn.setOnAction(e -> controller.deplacerLoup(Direction.HAUT, distanceLoupCombo.getValue()));
        basLoupBtn.setOnAction(e -> controller.deplacerLoup(Direction.BAS, distanceLoupCombo.getValue()));
        gaucheLoupBtn.setOnAction(e -> controller.deplacerLoup(Direction.GAUCHE, distanceLoupCombo.getValue()));
        droiteLoupBtn.setOnAction(e -> controller.deplacerLoup(Direction.DROITE, distanceLoupCombo.getValue()));
    }

    /**
     * Met à jour les informations affichées selon l'état de la simulation.
     * @param simulation La simulation en cours
     */
    public void mettreAJourInfos(Simulation simulation) {
        infoTour.setText("Tour: " + simulation.getNbTours());

        // Mettre à jour l'affichage de la vitesse du mouton
        int vitesseMouton = simulation.getMouton().getVitesse();
        infoMouton.setText("Mouton: Vitesse max " + vitesseMouton +
                " | Détecte loup: " + (simulation.getMouton().detecteAdversaire() ? "Oui" : "Non"));

        // Mettre à jour le combo de distance du mouton
        distanceMoutonCombo.getItems().clear();
        for (int i = 0; i <= vitesseMouton; i++) {
            distanceMoutonCombo.getItems().add(i);
        }

        // S'assurer que la valeur actuelle du combo est valide
        if (distanceMoutonCombo.getValue() == null || distanceMoutonCombo.getValue() > vitesseMouton) {
            distanceMoutonCombo.setValue(vitesseMouton);
        }

        // Mettre à jour l'affichage de la vitesse du loup
        int vitesseLoup = simulation.getLoup().getVitesse();
        infoLoup.setText("Loup: Vitesse " + vitesseLoup +
                " | Détecte mouton: " + (simulation.getLoup().detecteAdversaire() ? "Oui" : "Non"));

        // Mettre à jour le combo de distance du loup
        distanceLoupCombo.getItems().clear();
        for (int i = 0; i <= vitesseLoup; i++) {
            distanceLoupCombo.getItems().add(i);
        }

        // S'assurer que la valeur actuelle du combo est valide
        if (distanceLoupCombo.getValue() == null || distanceLoupCombo.getValue() > vitesseLoup) {
            distanceLoupCombo.setValue(vitesseLoup);
        }

        if (simulation.estTerminee()) {
            if (simulation.estMoutonVainqueur()) {
                // Victoire du mouton (texte vert)
                resultat.setText("VICTOIRE ! Le mouton s'est échappé après " + simulation.getNbTours() + " tours !");
                resultat.setTextFill(Color.GREEN);
                resultat.setBackground(new Background(new BackgroundFill(Color.LIGHTGREEN, new CornerRadii(5), Insets.EMPTY)));
            } else {
                // Défaite (texte rouge)
                resultat.setText("DÉFAITE ! Le loup a mangé le mouton après " + simulation.getNbTours() + " tours !");
                resultat.setTextFill(Color.RED);
                resultat.setBackground(new Background(new BackgroundFill(Color.LIGHTPINK, new CornerRadii(5), Insets.EMPTY)));
            }
            // Rendre le résultat visible
            resultat.setVisible(true);
            desactiverBoutons();

            // Afficher également une boîte de dialogue pour que ce soit encore plus visible
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Fin de la simulation");
            if (simulation.estMoutonVainqueur()) {
                alert.setHeaderText("VICTOIRE ! 🎉");
                alert.setContentText("Le mouton s'est échappé après " + simulation.getNbTours() + " tours !");
            } else {
                alert.setHeaderText("DÉFAITE ! 🐺");
                alert.setContentText("Le loup a mangé le mouton après " + simulation.getNbTours() + " tours !");
            }
            alert.showAndWait();
        }

        if (labyrinthCanvas != null) {
            labyrinthCanvas.redraw();
        }
    }

    /**
     * Désactive tous les boutons de contrôle.
     */
    private void desactiverBoutons() {
        hautBtn.setDisable(true);
        basBtn.setDisable(true);
        gaucheBtn.setDisable(true);
        droiteBtn.setDisable(true);
        distanceMoutonCombo.setDisable(true);
        distanceLoupCombo.setDisable(true); // Désactiver aussi le sélecteur de distance du loup
    }

    /**
     * Active tous les boutons de contrôle.
     */
    public void activerBoutons() {
        hautBtn.setDisable(false);
        basBtn.setDisable(false);
        gaucheBtn.setDisable(false);
        droiteBtn.setDisable(false);
        distanceMoutonCombo.setDisable(false);
        distanceLoupCombo.setDisable(false); // Activer aussi le sélecteur de distance du loup

        // Cacher le label de résultat au début d'une nouvelle partie
        resultat.setVisible(false);
    }

    /**
     * Définit le canevas du labyrinthe à afficher.
     * @param canvas Le canevas du labyrinthe
     */
    public void setLabyrinthCanvas(LabyrinthCanvas canvas) {
        if (this.labyrinthCanvas != null) {
            Node center = getCenter();
            if (center instanceof StackPane) {
                ((StackPane) center).getChildren().remove(this.labyrinthCanvas);
            }
        }

        this.labyrinthCanvas = canvas;

        // Ajouter le canvas dans le conteneur au centre
        Node center = getCenter();
        if (center instanceof StackPane) {
            ((StackPane) center).getChildren().add(canvas);
        }
    }

    /**
     * Retourne le contrôleur de simulation associé à ce panel.
     * @return Le contrôleur de simulation
     */
    public SimulationController getController() {
        return controller;
    }
}