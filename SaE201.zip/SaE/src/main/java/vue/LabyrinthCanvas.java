package vue;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import modele.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;

/**
 * Classe représentant le canevas d'affichage du labyrinthe.
 * Cette classe étend JavaFX Canvas et gère l'affichage graphique
 * du labyrinthe, des animaux et des interactions utilisateur.
 */
public class LabyrinthCanvas extends Canvas {
    /** La simulation en cours, peut être null en mode configuration */
    private Simulation simulation;

    /** Le labyrinthe à afficher */
    private Labyrinthe labyrinthe;

    /** Taille en pixels de chaque case du labyrinthe */
    private final int TAILLE_CASE = 50;

    /** Gestionnaire d'événements pour les clics sur les cellules */
    public CellClickHandler onCellClickedHandler;

    /** Position temporaire du mouton (utilisée en mode configuration) */
    private Position positionMoutonTemp;

    /** Position temporaire du loup (utilisée en mode configuration) */
    private Position positionLoupTemp;

    /** Map contenant les images pour chaque élément du jeu */
    private Map<String, Image> images = new HashMap<>();

    /**
     * Constructeur du canevas de labyrinthe.
     * @param simulation La simulation à afficher (peut être null en mode configuration)
     */
    public LabyrinthCanvas(Simulation simulation) {
        this.simulation = simulation;

        // Initialisation des dimensions selon que la simulation existe ou non
        if (simulation != null) {
            this.labyrinthe = simulation.getLabyrinthe();
            setWidth(labyrinthe.getLargeur() * TAILLE_CASE);
            setHeight(labyrinthe.getHauteur() * TAILLE_CASE);
        } else {
            // Dimensions par défaut si pas de simulation
            setWidth(500);
            setHeight(500);
        }

        // Chargement des images des éléments du jeu
        chargerImages();

        // Gestion des clics de souris pour interagir avec le labyrinthe
        setOnMouseClicked(e -> {
            // Conversion des coordonnées pixels en indices de grille
            double x = e.getX();
            double y = e.getY();
            int gridX = (int) (x / TAILLE_CASE);
            int gridY = (int) (y / TAILLE_CASE);
            // Notification du gestionnaire de clics s'il existe
            if (onCellClickedHandler != null) {
                onCellClickedHandler.handle(gridX, gridY);
            }
        });

        // Écouteurs pour redessiner le canevas quand sa taille change
        this.widthProperty().addListener((obs, oldVal, newVal) -> {
            System.out.println("Canvas redimensionné: largeur = " + newVal);
            redraw();
        });

        this.heightProperty().addListener((obs, oldVal, newVal) -> {
            System.out.println("Canvas redimensionné: hauteur = " + newVal);
            redraw();
        });
    }

    /**
     * Charge toutes les images nécessaires pour le jeu.
     * Tente plusieurs méthodes de chargement en cas d'échec.
     */
    private void chargerImages() {
        try {
            // Méthode 1: Chemin de ressource classique
            images.put("mouton", new Image(getClass().getResourceAsStream("/images/mouton.png")));
            images.put("loup", new Image(getClass().getResourceAsStream("/images/loup.png")));
            images.put("herbe", new Image(getClass().getResourceAsStream("/images/herbe.png")));
            images.put("marguerite", new Image(getClass().getResourceAsStream("/images/marguerite.png")));
            images.put("cactus", new Image(getClass().getResourceAsStream("/images/cactus.png")));
            images.put("rocher", new Image(getClass().getResourceAsStream("/images/rocher.png")));
            images.put("sortie", new Image(getClass().getResourceAsStream("/images/sortie.png")));

            System.out.println("Images chargées avec succès");
        } catch (Exception e) {
            System.err.println("Erreur lors du chargement des images (méthode 1): " + e.getMessage());
            e.printStackTrace();

            try {
                // Méthode 2: Chemin relatif sans slash au début
                images.put("mouton", new Image(getClass().getResourceAsStream("images/mouton.png")));
                images.put("loup", new Image(getClass().getResourceAsStream("images/loup.png")));
                images.put("herbe", new Image(getClass().getResourceAsStream("images/herbe.png")));
                images.put("marguerite", new Image(getClass().getResourceAsStream("images/marguerite.png")));
                images.put("cactus", new Image(getClass().getResourceAsStream("images/cactus.png")));
                images.put("rocher", new Image(getClass().getResourceAsStream("images/rocher.png")));
                images.put("sortie", new Image(getClass().getResourceAsStream("images/sortie.png")));
                System.out.println("Images chargées avec le chemin alternatif 1");
            } catch (Exception e2) {
                System.err.println("Erreur lors du chargement des images (méthode 2): " + e2.getMessage());

                try {
                    // Méthode 3: Chemin complet
                    images.put("mouton", new Image(getClass().getResourceAsStream("/com/example/sae/images/mouton.png")));
                    images.put("loup", new Image(getClass().getResourceAsStream("/com/example/sae/images/loup.png")));
                    images.put("herbe", new Image(getClass().getResourceAsStream("/com/example/sae/images/herbe.png")));
                    images.put("marguerite", new Image(getClass().getResourceAsStream("/com/example/sae/images/marguerite.png")));
                    images.put("cactus", new Image(getClass().getResourceAsStream("/com/example/sae/images/cactus.png")));
                    images.put("rocher", new Image(getClass().getResourceAsStream("/com/example/sae/images/rocher.png")));
                    images.put("sortie", new Image(getClass().getResourceAsStream("/com/example/sae/images/sortie.png")));
                    System.out.println("Images chargées avec le chemin alternatif 2");
                } catch (Exception e3) {
                    System.err.println("Erreur lors du chargement des images (méthode 3): " + e3.getMessage());

                    try {
                        // Méthode 4: Utilisation de FileInputStream avec chemin absolu
                        File projectRoot = new File(System.getProperty("user.dir"));
                        String path = projectRoot.getAbsolutePath() + "/src/main/resources/images/";
                        System.out.println("Tentative de chargement depuis: " + path);

                        images.put("mouton", new Image(new FileInputStream(path + "mouton.png")));
                        images.put("loup", new Image(new FileInputStream(path + "loup.png")));
                        images.put("herbe", new Image(new FileInputStream(path + "herbe.png")));
                        images.put("marguerite", new Image(new FileInputStream(path + "marguerite.png")));
                        images.put("cactus", new Image(new FileInputStream(path + "cactus.png")));
                        images.put("rocher", new Image(new FileInputStream(path + "rocher.png")));
                        images.put("sortie", new Image(new FileInputStream(path + "sortie.png")));

                        System.out.println("Images chargées avec FileInputStream");
                    } catch (FileNotFoundException e4) {
                        System.err.println("Impossible de trouver les fichiers d'image: " + e4.getMessage());
                        System.err.println("Utilisation des formes par défaut");
                    }
                }
            }
        }
    }

    /**
     * Définit un nouveau labyrinthe à afficher.
     * @param labyrinthe Le labyrinthe à afficher
     */
    public void setLabyrinthe(Labyrinthe labyrinthe) {
        this.labyrinthe = labyrinthe;

        // Ajuster les dimensions du canevas en fonction du labyrinthe
        if (labyrinthe != null) {
            setWidth(labyrinthe.getLargeur() * TAILLE_CASE);
            setHeight(labyrinthe.getHauteur() * TAILLE_CASE);
        }

        // Redessiner le canevas avec le nouveau labyrinthe
        redraw();
    }

    /**
     * Définit une nouvelle simulation à afficher.
     * @param simulation La simulation à afficher
     */
    public void setSimulation(Simulation simulation) {
        this.simulation = simulation;

        // Récupérer le labyrinthe de la simulation et ajuster les dimensions
        if (simulation != null) {
            this.labyrinthe = simulation.getLabyrinthe();
            setWidth(labyrinthe.getLargeur() * TAILLE_CASE);
            setHeight(labyrinthe.getHauteur() * TAILLE_CASE);
        }

        // Redessiner le canevas avec la nouvelle simulation
        redraw();
    }

    /**
     * Définit la position temporaire du mouton (en mode configuration).
     * @param position La position temporaire du mouton
     */
    public void setPositionMoutonTemp(Position position) {
        this.positionMoutonTemp = position;
        redraw();
    }

    /**
     * Définit la position temporaire du loup (en mode configuration).
     * @param position La position temporaire du loup
     */
    public void setPositionLoupTemp(Position position) {
        this.positionLoupTemp = position;
        redraw();
    }

    /**
     * Efface les positions temporaires des animaux.
     */
    public void clearPositionsTemp() {
        this.positionMoutonTemp = null;
        this.positionLoupTemp = null;
        redraw();
    }

    /**
     * Méthode principale de dessin du labyrinthe et des animaux.
     * Cette méthode redessine entièrement le canevas.
     */
    public void redraw() {
        // Vérifier que le labyrinthe existe
        if (labyrinthe == null) {
            System.out.println("Labyrinthe null, impossible de dessiner");
            return;
        }

        System.out.println("Dessin du labyrinthe : " + labyrinthe.getLargeur() + "x" + labyrinthe.getHauteur());
        System.out.println("Dimensions du canvas : " + getWidth() + "x" + getHeight());

        // Obtenir le contexte graphique pour dessiner
        GraphicsContext gc = getGraphicsContext2D();
        if (gc == null) {
            System.out.println("ERREUR: GraphicsContext est null");
            return;
        }

        // Effacer le contenu précédent
        gc.clearRect(0, 0, getWidth(), getHeight());

        // Afficher la position de la sortie pour le débogage
        System.out.println("Position de la sortie : " +
                (labyrinthe.getPositionSortie() != null ?
                        labyrinthe.getPositionSortie().toString() : "non définie"));

        // Dessiner le labyrinthe case par case
        for (int y = 0; y < labyrinthe.getHauteur(); y++) {
            for (int x = 0; x < labyrinthe.getLargeur(); x++) {
                int posX = x * TAILLE_CASE;
                int posY = y * TAILLE_CASE;

                // Récupérer le type de case à cette position
                TypeCase typeCase = labyrinthe.getTypeCase(x, y);
                if (typeCase == null) {
                    System.out.println("TypeCase null à la position " + x + "," + y);
                    continue;
                }

                // Dessiner l'élément selon son type
                switch (typeCase) {
                    case ROCHER:
                        System.out.println("Dessin d'un rocher à : " + x + "," + y);
                        if (images.containsKey("rocher") && images.get("rocher") != null) {
                            System.out.println("Utilisation de l'image pour le rocher");
                            gc.drawImage(images.get("rocher"), posX, posY, TAILLE_CASE, TAILLE_CASE);
                        } else {
                            System.out.println("Utilisation de la forme par défaut pour le rocher");
                            gc.setFill(Color.GRAY);
                            gc.fillRect(posX, posY, TAILLE_CASE, TAILLE_CASE);
                        }
                        break;
                    case HERBE:
                        // Dessiner l'herbe normalement
                        if (images.containsKey("herbe") && images.get("herbe") != null) {
                            gc.drawImage(images.get("herbe"), posX, posY, TAILLE_CASE, TAILLE_CASE);
                        } else {
                            gc.setFill(Color.LIGHTGREEN);
                            gc.fillRect(posX, posY, TAILLE_CASE, TAILLE_CASE);
                        }
                        break;
                    case MARGUERITE:
                        // Dessiner l'herbe comme fond pour la marguerite
                        if (images.containsKey("herbe") && images.get("herbe") != null) {
                            gc.drawImage(images.get("herbe"), posX, posY, TAILLE_CASE, TAILLE_CASE);
                        } else {
                            gc.setFill(Color.LIGHTGREEN);
                            gc.fillRect(posX, posY, TAILLE_CASE, TAILLE_CASE);
                        }

                        // Dessiner la marguerite par-dessus l'herbe
                        if (images.containsKey("marguerite") && images.get("marguerite") != null) {
                            gc.drawImage(images.get("marguerite"), posX, posY, TAILLE_CASE, TAILLE_CASE);
                        } else {
                            // Dessin simplifié d'une marguerite (cercle blanc avec centre jaune)
                            gc.setFill(Color.WHITE);
                            gc.fillOval(posX + 12.5, posY + 12.5, TAILLE_CASE - 25, TAILLE_CASE - 25);
                            gc.setFill(Color.YELLOW);
                            gc.fillOval(posX + 18.75, posY + 18.75, TAILLE_CASE - 37.5, TAILLE_CASE - 37.5);
                        }
                        break;
                    case CACTUS:
                        // Dessiner l'herbe comme fond pour le cactus
                        if (images.containsKey("herbe") && images.get("herbe") != null) {
                            gc.drawImage(images.get("herbe"), posX, posY, TAILLE_CASE, TAILLE_CASE);
                        } else {
                            gc.setFill(Color.LIGHTGREEN);
                            gc.fillRect(posX, posY, TAILLE_CASE, TAILLE_CASE);
                        }

                        // Dessiner le cactus par-dessus l'herbe
                        if (images.containsKey("cactus") && images.get("cactus") != null) {
                            gc.drawImage(images.get("cactus"), posX, posY, TAILLE_CASE, TAILLE_CASE);
                        } else {
                            // Dessin simplifié d'un cactus (rectangle vert foncé)
                            gc.setFill(Color.DARKGREEN);
                            gc.fillRect(posX + 18.75, posY + 6.25, TAILLE_CASE - 37.5, TAILLE_CASE - 12.5);
                        }
                        break;
                    case SORTIE:
                        System.out.println("Dessin de la sortie à : " + x + "," + y);
                        if (images.containsKey("sortie") && images.get("sortie") != null) {
                            System.out.println("Utilisation de l'image pour la sortie");
                            gc.drawImage(images.get("sortie"), posX, posY, TAILLE_CASE, TAILLE_CASE);
                        } else {
                            System.out.println("Utilisation de la forme par défaut pour la sortie");
                            gc.setFill(Color.RED);
                            gc.fillRect(posX, posY, TAILLE_CASE, TAILLE_CASE);
                        }
                        break;
                }

                // Dessiner les bordures des cases
                gc.setStroke(Color.BLACK);
                gc.strokeRect(posX, posY, TAILLE_CASE, TAILLE_CASE);
            }
        }

        // Dessiner les animaux en mode simulation
        if (simulation != null) {
            // Dessiner le mouton à sa position actuelle
            Position posMouton = simulation.getMouton().getPosition();
            int moutonX = posMouton.getX() * TAILLE_CASE;
            int moutonY = posMouton.getY() * TAILLE_CASE;

            if (images.containsKey("mouton") && images.get("mouton") != null) {
                gc.drawImage(images.get("mouton"), moutonX, moutonY, TAILLE_CASE, TAILLE_CASE);
            } else {
                // Dessin simplifié d'un mouton (cercle blanc)
                gc.setFill(Color.WHITE);
                gc.fillOval(moutonX + 6.25, moutonY + 6.25, TAILLE_CASE - 12.5, TAILLE_CASE - 12.5);
                gc.setStroke(Color.BLACK);
                gc.strokeOval(moutonX + 6.25, moutonY + 6.25, TAILLE_CASE - 12.5, TAILLE_CASE - 12.5);
            }

            // Dessiner le loup à sa position actuelle
            Position posLoup = simulation.getLoup().getPosition();
            int loupX = posLoup.getX() * TAILLE_CASE;
            int loupY = posLoup.getY() * TAILLE_CASE;

            if (images.containsKey("loup") && images.get("loup") != null) {
                gc.drawImage(images.get("loup"), loupX, loupY, TAILLE_CASE, TAILLE_CASE);
            } else {
                // Dessin simplifié d'un loup (cercle gris foncé)
                gc.setFill(Color.DARKGRAY);
                gc.fillOval(loupX + 6.25, loupY + 6.25, TAILLE_CASE - 12.5, TAILLE_CASE - 12.5);
                gc.setStroke(Color.BLACK);
                gc.strokeOval(loupX + 6.25, loupY + 6.25, TAILLE_CASE - 12.5, TAILLE_CASE - 12.5);
            }
        }
        // Dessiner les prévisualisations en mode configuration
        else {
            // Prévisualisation du mouton (si position temporaire définie)
            if (positionMoutonTemp != null) {
                int moutonX = positionMoutonTemp.getX() * TAILLE_CASE;
                int moutonY = positionMoutonTemp.getY() * TAILLE_CASE;

                if (images.containsKey("mouton") && images.get("mouton") != null) {
                    // Rendre l'image semi-transparente
                    gc.setGlobalAlpha(0.7);
                    gc.drawImage(images.get("mouton"), moutonX, moutonY, TAILLE_CASE, TAILLE_CASE);
                    gc.setGlobalAlpha(1.0); // Restaurer l'opacité
                } else {
                    // Dessin simplifié d'un mouton semi-transparent
                    gc.setFill(Color.WHITE);
                    gc.setGlobalAlpha(0.7);
                    gc.fillOval(moutonX + 6.25, moutonY + 6.25, TAILLE_CASE - 12.5, TAILLE_CASE - 12.5);
                    gc.setStroke(Color.BLACK);
                    gc.strokeOval(moutonX + 6.25, moutonY + 6.25, TAILLE_CASE - 12.5, TAILLE_CASE - 12.5);
                    gc.setGlobalAlpha(1.0);
                }

                // Afficher une étiquette "Mouton"
                gc.setFill(Color.BLACK);
                gc.fillText("Mouton", moutonX + 2.5, moutonY + 12.5);
            }

            // Prévisualisation du loup (si position temporaire définie)
            if (positionLoupTemp != null) {
                int loupX = positionLoupTemp.getX() * TAILLE_CASE;
                int loupY = positionLoupTemp.getY() * TAILLE_CASE;

                if (images.containsKey("loup") && images.get("loup") != null) {
                    // Rendre l'image semi-transparente
                    gc.setGlobalAlpha(0.7);
                    gc.drawImage(images.get("loup"), loupX, loupY, TAILLE_CASE, TAILLE_CASE);
                    gc.setGlobalAlpha(1.0);
                } else {
                    // Dessin simplifié d'un loup semi-transparent
                    gc.setFill(Color.DARKGRAY);
                    gc.setGlobalAlpha(0.7);
                    gc.fillOval(loupX + 6.25, loupY + 6.25, TAILLE_CASE - 12.5, TAILLE_CASE - 12.5);
                    gc.setStroke(Color.BLACK);
                    gc.strokeOval(loupX + 6.25, loupY + 6.25, TAILLE_CASE - 12.5, TAILLE_CASE - 12.5);
                    gc.setGlobalAlpha(1.0);
                }

                // Afficher une étiquette "Loup"
                gc.setFill(Color.BLACK);
                gc.fillText("Loup", loupX + 2.5, loupY + 12.5);
            }
        }
    }

    /**
     * Interface fonctionnelle pour gérer les clics sur les cellules du labyrinthe.
     */
    public interface CellClickHandler {
        /**
         * Méthode appelée lorsqu'une cellule est cliquée.
         * @param x Coordonnée X de la cellule (indice dans la grille)
         * @param y Coordonnée Y de la cellule (indice dans la grille)
         */
        void handle(int x, int y);
    }

    /**
     * Définit le gestionnaire de clics pour les cellules du labyrinthe.
     * @param handler Le gestionnaire à utiliser
     */
    public void setOnCellClicked(CellClickHandler handler) {
        this.onCellClickedHandler = handler;
    }
}