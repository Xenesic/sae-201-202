package vue;

import controleur.*;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import modele.*;

import java.io.File;
import java.io.IOException;

public class ConfigurationPanel extends VBox {
    private TextField hauteurField;
    private TextField largeurField;
    private Button creerLabyrintheBtn;
    public Button choisirSortieBtn;
    private ComboBox<TypeCase> typeCaseCombo;
    private Button placerElementBtn;
    public Button verrouillerCarteBtn;
    private Button placerMoutonBtn;
    private Button placerLoupBtn;
    private Button lancerSimulationBtn;
    private Button sauvegarderBtn;
    private Button chargerBtn;

    private ConfigurationController controller;

    public ConfigurationPanel(ConfigurationController controller) {
        this.controller = controller;
        initialiserComposants();
    }

    private void initialiserComposants() {
        setPadding(new Insets(10));
        setSpacing(10);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        // Dimension du labyrinthe
        grid.add(new Label("Hauteur:"), 0, 0);
        hauteurField = new TextField("10");
        hauteurField.setPrefWidth(100);
        grid.add(hauteurField, 1, 0);

        grid.add(new Label("Largeur:"), 0, 1);
        largeurField = new TextField("10");
        largeurField.setPrefWidth(100);
        grid.add(largeurField, 1, 1);

        // Bouton pour créer le labyrinthe
        creerLabyrintheBtn = new Button("Créer Labyrinthe");
        creerLabyrintheBtn.setMaxWidth(Double.MAX_VALUE);
        grid.add(creerLabyrintheBtn, 0, 2, 2, 1);

        // Bouton pour choisir la sortie
        choisirSortieBtn = new Button("Choisir Sortie");
        choisirSortieBtn.setMaxWidth(Double.MAX_VALUE);
        choisirSortieBtn.setDisable(true);
        grid.add(choisirSortieBtn, 0, 3, 2, 1);

        // Choix du type de case à placer
        grid.add(new Label("Type de case:"), 0, 4);
        typeCaseCombo = new ComboBox<>();
        typeCaseCombo.getItems().addAll(TypeCase.ROCHER, TypeCase.HERBE, TypeCase.MARGUERITE, TypeCase.CACTUS);
        typeCaseCombo.setValue(TypeCase.ROCHER);
        typeCaseCombo.setPrefWidth(150);
        grid.add(typeCaseCombo, 1, 4);

        // Bouton pour placer des éléments
        placerElementBtn = new Button("Placer Élément");
        placerElementBtn.setMaxWidth(Double.MAX_VALUE);
        placerElementBtn.setDisable(true);
        grid.add(placerElementBtn, 0, 5, 2, 1);

        // Bouton pour verrouiller la carte
        verrouillerCarteBtn = new Button("Verrouiller Carte");
        verrouillerCarteBtn.setMaxWidth(Double.MAX_VALUE);
        verrouillerCarteBtn.setDisable(true);
        grid.add(verrouillerCarteBtn, 0, 6, 2, 1);

        // Bouton pour placer le mouton
        placerMoutonBtn = new Button("Placer Mouton");
        placerMoutonBtn.setMaxWidth(Double.MAX_VALUE);
        placerMoutonBtn.setDisable(true);
        grid.add(placerMoutonBtn, 0, 7, 2, 1);

        // Bouton pour placer le loup
        placerLoupBtn = new Button("Placer Loup");
        placerLoupBtn.setMaxWidth(Double.MAX_VALUE);
        placerLoupBtn.setDisable(true);
        grid.add(placerLoupBtn, 0, 8, 2, 1);

        // Bouton pour lancer la simulation
        lancerSimulationBtn = new Button("Lancer Simulation");
        lancerSimulationBtn.setMaxWidth(Double.MAX_VALUE);
        lancerSimulationBtn.setDisable(true);
        grid.add(lancerSimulationBtn, 0, 9, 2, 1);

        // Boutons pour sauvegarder/charger
        VBox saveLoadBox = new VBox(10);
        sauvegarderBtn = new Button("Sauvegarder");
        sauvegarderBtn.setMaxWidth(Double.MAX_VALUE);
        sauvegarderBtn.setDisable(true);

        chargerBtn = new Button("Charger");
        chargerBtn.setMaxWidth(Double.MAX_VALUE);

        saveLoadBox.getChildren().addAll(sauvegarderBtn, chargerBtn);
        grid.add(saveLoadBox, 0, 10, 2, 1);

        getChildren().add(grid);

        // Ajouter les écouteurs d'événements
        creerLabyrintheBtn.setOnAction(e -> {
            try {
                int hauteur = Integer.parseInt(hauteurField.getText());
                int largeur = Integer.parseInt(largeurField.getText());
                controller.creerLabyrinthe(hauteur, largeur);
                choisirSortieBtn.setDisable(false);
                placerElementBtn.setDisable(true);
                verrouillerCarteBtn.setDisable(true);
                placerMoutonBtn.setDisable(true);
                placerLoupBtn.setDisable(true);
                lancerSimulationBtn.setDisable(true);
                sauvegarderBtn.setDisable(false);
            } catch (NumberFormatException ex) {
                new Alert(Alert.AlertType.ERROR, "Veuillez entrer des nombres valides pour les dimensions").showAndWait();
            }
        });

        choisirSortieBtn.setOnAction(e -> {
            controller.setModeChoisirSortie();
            placerElementBtn.setDisable(false);
        });

        placerElementBtn.setOnAction(e -> {
            TypeCase typeCase = typeCaseCombo.getValue();
            controller.setModePlacerElement(typeCase);
        });

        verrouillerCarteBtn.setOnAction(e -> {
            if (controller.verrouillerCarte()) {
                placerMoutonBtn.setDisable(false);
                placerLoupBtn.setDisable(false);
                placerElementBtn.setDisable(true);
                choisirSortieBtn.setDisable(true);
            } else {
                new Alert(Alert.AlertType.ERROR, "La carte n'est pas valide (vérifiez que la sortie est définie)").showAndWait();
            }
        });

        placerMoutonBtn.setOnAction(e -> {
            controller.setModePlacerMouton();
        });

        placerLoupBtn.setOnAction(e -> {
            controller.setModePlacerLoup();
        });

        lancerSimulationBtn.setOnAction(e -> {
            controller.lancerSimulation();
        });

        sauvegarderBtn.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Sauvegarder le labyrinthe");
            fileChooser.getExtensionFilters().add(
                    new FileChooser.ExtensionFilter("Fichiers labyrinthe", "*.lab")
            );
            File file = fileChooser.showSaveDialog(getScene().getWindow());
            if (file != null) {
                try {
                    controller.sauvegarderLabyrinthe(file.getPath());
                } catch (IOException ex) {
                    new Alert(Alert.AlertType.ERROR, "Erreur lors de la sauvegarde: " + ex.getMessage()).showAndWait();
                }
            }
        });

        chargerBtn.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Charger un labyrinthe");
            fileChooser.getExtensionFilters().add(
                    new FileChooser.ExtensionFilter("Fichiers labyrinthe", "*.lab")
            );
            File file = fileChooser.showOpenDialog(getScene().getWindow());
            if (file != null) {
                try {
                    controller.chargerLabyrinthe(file.getPath());
                    choisirSortieBtn.setDisable(true);
                    placerElementBtn.setDisable(false);
                    verrouillerCarteBtn.setDisable(false);
                    sauvegarderBtn.setDisable(false);
                } catch (Exception ex) {
                    new Alert(Alert.AlertType.ERROR, "Erreur lors du chargement: " + ex.getMessage()).showAndWait();
                }
            }
        });
    }

    public void activerPlacerMoutonLoup() {
        placerMoutonBtn.setDisable(false);
        placerLoupBtn.setDisable(false);
    }

    public void activerLancerSimulation() {
        lancerSimulationBtn.setDisable(false);
    }
}