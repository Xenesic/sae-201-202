package vue;

import controleur.*;
import javafx.scene.Scene;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import modele.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

public class MainWindow {
    private Stage primaryStage;
    private ConfigurationPanel configPanel;
    private SimulationPanel simulationPanel;
    private LabyrinthCanvas labyrinthCanvas;
    private TabPane tabPane;
    private BorderPane configContainerPane;

    private ConfigurationController configController;
    private SimulationController simulationController;

    public MainWindow(Stage primaryStage) {
        this.primaryStage = primaryStage;
        primaryStage.setTitle("Mange-moi si tu peux !");

        initialiserControleurs();
        initialiserComposants();

        Scene scene = new Scene(tabPane, 800, 600);
        primaryStage.setScene(scene);

        // Appliquer un fond d'écran à toute la fenêtre principale
        appliquerFondEcran();

        primaryStage.show();
    }

    private void appliquerFondEcran() {
        try {
            // Essayer différentes méthodes pour charger l'image de fond
            Image backgroundImage = null;

            // Méthode 1: Chemin de ressource classique
            try {
                InputStream inputStream = getClass().getResourceAsStream("/images/background.png");
                if (inputStream != null) {
                    backgroundImage = new Image(inputStream);
                    System.out.println("Image de fond chargée avec le chemin classique");
                }
            } catch (Exception e1) {
                System.err.println("Erreur méthode 1: " + e1.getMessage());
            }

            // Méthode 2: Chemin relatif sans slash au début
            if (backgroundImage == null) {
                try {
                    InputStream inputStream = getClass().getResourceAsStream("images/background.png");
                    if (inputStream != null) {
                        backgroundImage = new Image(inputStream);
                        System.out.println("Image de fond chargée avec le chemin alternatif 1");
                    }
                } catch (Exception e2) {
                    System.err.println("Erreur méthode 2: " + e2.getMessage());
                }
            }

            // Méthode 3: Chemin complet avec package
            if (backgroundImage == null) {
                try {
                    InputStream inputStream = getClass().getResourceAsStream("/com/example/sae/images/background.png");
                    if (inputStream != null) {
                        backgroundImage = new Image(inputStream);
                        System.out.println("Image de fond chargée avec le chemin alternatif 2");
                    }
                } catch (Exception e3) {
                    System.err.println("Erreur méthode 3: " + e3.getMessage());
                }
            }

            // Méthode 4: Utilisation de FileInputStream avec chemin absolu
            if (backgroundImage == null) {
                try {
                    File projectRoot = new File(System.getProperty("user.dir"));
                    String path = projectRoot.getAbsolutePath() + "/src/main/resources/images/background.png";
                    System.out.println("Tentative de chargement depuis: " + path);

                    backgroundImage = new Image(new FileInputStream(path));
                    System.out.println("Image de fond chargée avec FileInputStream");
                } catch (Exception e4) {
                    System.err.println("Erreur méthode 4: " + e4.getMessage());
                }
            }

            if (backgroundImage != null) {
                BackgroundImage background = new BackgroundImage(
                        backgroundImage,
                        BackgroundRepeat.REPEAT,
                        BackgroundRepeat.REPEAT,
                        BackgroundPosition.DEFAULT,
                        new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, true, true));

                // Appliquer le fond d'écran à tous les conteneurs
                Background bg = new Background(background);
                tabPane.setBackground(bg);
                configContainerPane.setBackground(bg);
                simulationPanel.setBackground(bg);
                configPanel.setBackground(bg);

                System.out.println("Fond d'écran appliqué avec succès");
            } else {
                System.err.println("Impossible de charger l'image de fond");
            }
        } catch (Exception e) {
            System.err.println("Erreur lors de l'application du fond d'écran: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void initialiserControleurs() {
        configController = new ConfigurationController(this);
        simulationController = new SimulationController(this);
    }

    private void initialiserComposants() {
        tabPane = new TabPane();

        // Créer les panels
        configPanel = new ConfigurationPanel(configController);
        simulationPanel = new SimulationPanel(simulationController);
        labyrinthCanvas = new LabyrinthCanvas(null);

        // Configurer le panel de configuration
        configContainerPane = new BorderPane();
        configContainerPane.setPrefSize(800, 600);
        configContainerPane.setLeft(configPanel);
        configContainerPane.setCenter(labyrinthCanvas);

        // Ajouter les onglets
        Tab configTab = new Tab("Configuration", configContainerPane);
        configTab.setClosable(false);
        tabPane.getTabs().add(configTab);

        Tab simulationTab = new Tab("Simulation", simulationPanel);
        simulationTab.setClosable(false);
        tabPane.getTabs().add(simulationTab);
    }

    public ConfigurationPanel getConfigPanel() {
        return configPanel;
    }

    public SimulationPanel getSimulationPanel() {
        return simulationPanel;
    }

    public LabyrinthCanvas getLabyrinthCanvas() {
        return labyrinthCanvas;
    }

    public void setLabyrinthCanvas(LabyrinthCanvas canvas) {
        if (this.labyrinthCanvas != null) {
            configContainerPane.getChildren().remove(this.labyrinthCanvas);
        }

        this.labyrinthCanvas = canvas;
        configContainerPane.setCenter(canvas);

        System.out.println("Canvas remplacé. Dimensions: " + canvas.getWidth() + "x" + canvas.getHeight());
    }

    public void basculerVersSimulation() {
        tabPane.getSelectionModel().select(1); // Sélectionner l'onglet Simulation
    }
}