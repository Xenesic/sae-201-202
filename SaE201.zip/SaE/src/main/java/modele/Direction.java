package modele;

import java.io.Serializable;

public enum Direction implements Serializable {
    HAUT,
    BAS,
    GAUCHE,
    DROITE
}