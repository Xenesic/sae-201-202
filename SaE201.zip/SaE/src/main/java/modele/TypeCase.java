package modele;

import java.io.Serializable;

public enum TypeCase implements Serializable {
    ROCHER,
    HERBE,
    MARGUERITE,
    CACTUS,
    SORTIE
}