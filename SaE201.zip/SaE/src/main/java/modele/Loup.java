package modele;

/**
 * Classe représentant un loup dans le jeu.
 * Le loup est un prédateur qui chasse le mouton.
 */
public class Loup extends Animal {

    /**
     * Constructeur du loup.
     * @param position La position initiale du loup
     */
    public Loup(Position position) {
        super(position, 3, 5); // vitesse fixe de 3, vision 5
    }

    /**
     * Vérifie si le loup peut se déplacer dans la direction spécifiée.
     * @param direction La direction du déplacement
     * @param labyrinthe Le labyrinthe dans lequel se déplace le loup
     * @return true si le déplacement est possible, false sinon
     */
    @Override
    public boolean peutSeDeplacer(Direction direction, Labyrinthe labyrinthe) {
        // Le loup peut toujours tenter de se déplacer
        return true;
    }

    /**
     * Déplace le loup dans la direction spécifiée (avec sa vitesse maximale).
     * @param direction La direction du déplacement
     * @param labyrinthe Le labyrinthe dans lequel se déplace le loup
     */
    @Override
    public void deplacer(Direction direction, Labyrinthe labyrinthe) {
        // Utiliser la méthode avec distance en utilisant la vitesse maximale
        deplacer(direction, vitesse, labyrinthe);
    }

    /**
     * Déplace le loup dans la direction spécifiée avec une distance donnée.
     * @param direction La direction du déplacement
     * @param distance La distance à parcourir (limitée par la vitesse du loup)
     * @param labyrinthe Le labyrinthe dans lequel se déplace le loup
     */
    public void deplacer(Direction direction, int distance, Labyrinthe labyrinthe) {
        // Limiter la distance au maximum autorisé par la vitesse
        int distanceEffective = Math.min(distance, vitesse);

        System.out.println("Loup tente de se déplacer de " + distanceEffective + " cases");

        for (int i = 0; i < distanceEffective; i++) {
            int newX = position.getX();
            int newY = position.getY();

            switch (direction) {
                case HAUT: newY--; break;
                case BAS: newY++; break;
                case GAUCHE: newX--; break;
                case DROITE: newX++; break;
            }

            // Vérifier si les nouvelles coordonnées sont valides
            if (newX < 0 || newX >= labyrinthe.getLargeur() ||
                    newY < 0 || newY >= labyrinthe.getHauteur() ||
                    labyrinthe.getTypeCase(newX, newY) == TypeCase.ROCHER ||
                    labyrinthe.getTypeCase(newX, newY) == TypeCase.SORTIE) {
                System.out.println("Loup bloqué après " + i + " cases");
                break; // Arrêter le déplacement si on rencontre un obstacle
            }

            // Mettre à jour la position
            position.setX(newX);
            position.setY(newY);
        }
    }
}