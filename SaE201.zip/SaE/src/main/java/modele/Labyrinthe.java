package modele;

import java.io.*;
import java.util.*;

public class Labyrinthe implements Serializable {
    private TypeCase[][] grille;
    private int hauteur;
    private int largeur;
    private Position positionSortie;

    public Labyrinthe(int hauteur, int largeur) {
        this.hauteur = hauteur;
        this.largeur = largeur;
        this.grille = new TypeCase[hauteur][largeur];
        initialiserLabyrinthe();
    }

    private void initialiserLabyrinthe() {
        // Remplir toutes les cases avec de l'herbe
        for (int y = 0; y < hauteur; y++) {
            for (int x = 0; x < largeur; x++) {
                grille[y][x] = TypeCase.HERBE;
            }
        }

        // Ajouter des rochers sur les bords
        for (int y = 0; y < hauteur; y++) {
            grille[y][0] = TypeCase.ROCHER;
            grille[y][largeur - 1] = TypeCase.ROCHER;
        }

        for (int x = 0; x < largeur; x++) {
            grille[0][x] = TypeCase.ROCHER;
            grille[hauteur - 1][x] = TypeCase.ROCHER;
        }
    }

    public void setPositionSortie(int x, int y) {
        if (grille[y][x] == TypeCase.ROCHER) {
            grille[y][x] = TypeCase.SORTIE;
            positionSortie = new Position(x, y);
        }
    }

    public Position getPositionSortie() {
        return positionSortie;
    }

    public void setTypeCase(int x, int y, TypeCase type) {
        if (x >= 0 && x < largeur && y >= 0 && y < hauteur) {
            grille[y][x] = type;
            if (type == TypeCase.SORTIE) {
                positionSortie = new Position(x, y);
            }
        }
    }

    public TypeCase getTypeCase(int x, int y) {
        if (x >= 0 && x < largeur && y >= 0 && y < hauteur) {
            return grille[y][x];
        }
        return null;
    }

    public int getHauteur() {
        return hauteur;
    }

    public int getLargeur() {
        return largeur;
    }

    // Vérifier si la sortie est atteignable depuis toutes les cases intérieures
    public boolean estSortieAtteignable(Position positionTest) {
        if (positionSortie == null) {
            return false;
        }

        boolean[][] visite = new boolean[hauteur][largeur];

        // Recherche en largeur (BFS)
        Queue<Position> file = new LinkedList<>();
        file.add(positionTest);
        visite[positionTest.getY()][positionTest.getX()] = true;

        while (!file.isEmpty()) {
            Position position = file.poll();

            if (position.equals(positionSortie)) {
                return true;
            }

            // Vérifier les cases adjacentes
            int[][] directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}}; // haut, bas, gauche, droite

            for (int[] dir : directions) {
                int nx = position.getX() + dir[0];
                int ny = position.getY() + dir[1];

                if (nx >= 0 && nx < largeur && ny >= 0 && ny < hauteur &&
                        !visite[ny][nx] && grille[ny][nx] != TypeCase.ROCHER) {
                    file.add(new Position(nx, ny));
                    visite[ny][nx] = true;
                }
            }
        }

        return false;
    }

    // Sauvegarder le labyrinthe dans un fichier
    public void sauvegarder(String nomFichier) throws IOException {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(nomFichier))) {
            out.writeObject(this);
        }
    }

    // Charger le labyrinthe depuis un fichier
    public static Labyrinthe charger(String nomFichier) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(nomFichier))) {
            return (Labyrinthe) in.readObject();
        }
    }
}