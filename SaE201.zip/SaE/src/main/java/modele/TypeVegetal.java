package modele;

import java.io.Serializable;

public enum TypeVegetal implements Serializable {
    HERBE,
    MARGUERITE,
    CACTUS
}