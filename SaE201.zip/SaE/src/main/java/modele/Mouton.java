package modele;

public class Mouton extends Animal {
    private int nbHerbesConsommees;
    private int nbMargueritesConsommees;
    private int nbCactusConsommes;
    private TypeVegetal dernierVegetalConsomme;

    public Mouton(Position position) {
        super(position, 2, 5); // vitesse maximale 2 par défaut, vision 5
        this.nbHerbesConsommees = 0;
        this.nbMargueritesConsommees = 0;
        this.nbCactusConsommes = 0;
        this.dernierVegetalConsomme = TypeVegetal.HERBE; // Par défaut
    }

    public int getNbHerbesConsommees() {
        return nbHerbesConsommees;
    }

    public int getNbMargueritesConsommees() {
        return nbMargueritesConsommees;
    }

    public int getNbCactusConsommes() {
        return nbCactusConsommes;
    }

    public TypeVegetal getDernierVegetalConsomme() {
        return dernierVegetalConsomme;
    }

    @Override
    public boolean peutSeDeplacer(Direction direction, Labyrinthe labyrinthe) {
        // Le mouton peut toujours se déplacer (le contrôle de la distance validera si c'est possible)
        return true;
    }

    // Nouvelle méthode pour le déplacement avec distance spécifiée
    public void deplacer(Direction direction, int distance, Labyrinthe labyrinthe) {
        // Limiter la distance au maximum autorisé par la vitesse actuelle
        int distanceEffective = Math.min(distance, vitesse);

        System.out.println("Mouton se déplace de " + distanceEffective + " cases");

        for (int i = 0; i < distanceEffective; i++) {
            int newX = position.getX();
            int newY = position.getY();

            switch (direction) {
                case HAUT: newY--; break;
                case BAS: newY++; break;
                case GAUCHE: newX--; break;
                case DROITE: newX++; break;
            }

            // Vérifier si les nouvelles coordonnées sont valides
            if (newX < 0 || newX >= labyrinthe.getLargeur() ||
                    newY < 0 || newY >= labyrinthe.getHauteur() ||
                    labyrinthe.getTypeCase(newX, newY) == TypeCase.ROCHER) {
                break; // Arrêter le déplacement si on rencontre un obstacle
            }

            // Mettre à jour la position
            position.setX(newX);
            position.setY(newY);
        }

        // Consommer le végétal sur la case
        consommerVegetal(labyrinthe);
    }

    @Override
    public void deplacer(Direction direction, Labyrinthe labyrinthe) {
        // Appeler la version avec distance en utilisant la vitesse maximale
        deplacer(direction, vitesse, labyrinthe);
    }

    private void consommerVegetal(Labyrinthe labyrinthe) {
        TypeCase typeCase = labyrinthe.getTypeCase(position.getX(), position.getY());

        switch (typeCase) {
            case HERBE:
                nbHerbesConsommees++;
                vitesse = 2;  // Peut avancer jusqu'à 2 cases
                dernierVegetalConsomme = TypeVegetal.HERBE;
                break;
            case MARGUERITE:
                nbMargueritesConsommees++;
                vitesse = 3;  // Peut avancer jusqu'à 3 cases
                dernierVegetalConsomme = TypeVegetal.MARGUERITE;
                break;
            case CACTUS:
                nbCactusConsommes++;
                vitesse = 1;  // Peut avancer jusqu'à 1 case
                dernierVegetalConsomme = TypeVegetal.CACTUS;
                break;
            case SORTIE:
                // Le mouton est sorti
                break;
        }
    }
}