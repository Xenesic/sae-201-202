package modele;

/**
 * Classe représentant une simulation du jeu.
 * Gère l'état du jeu et les règles de déplacement des animaux.
 */
public class Simulation {
    private Labyrinthe labyrinthe;
    private Mouton mouton;
    private Loup loup;
    private int nbTours;
    private boolean estTerminee;
    private boolean moutonVainqueur;

    /**
     * Constructeur de la simulation.
     * @param labyrinthe Le labyrinthe utilisé pour la simulation
     * @param positionMouton La position initiale du mouton
     * @param positionLoup La position initiale du loup
     */
    public Simulation(Labyrinthe labyrinthe, Position positionMouton, Position positionLoup) {
        this.labyrinthe = labyrinthe;
        this.mouton = new Mouton(positionMouton);
        this.loup = new Loup(positionLoup);
        this.nbTours = 0;
        this.estTerminee = false;
        this.moutonVainqueur = false;
    }

    /**
     * Accesseur pour le labyrinthe.
     * @return Le labyrinthe de la simulation
     */
    public Labyrinthe getLabyrinthe() {
        return labyrinthe;
    }

    /**
     * Accesseur pour le mouton.
     * @return Le mouton de la simulation
     */
    public Mouton getMouton() {
        return mouton;
    }

    /**
     * Accesseur pour le loup.
     * @return Le loup de la simulation
     */
    public Loup getLoup() {
        return loup;
    }

    /**
     * Accesseur pour le nombre de tours.
     * @return Le nombre de tours écoulés
     */
    public int getNbTours() {
        return nbTours;
    }

    /**
     * Vérifie si la simulation est terminée.
     * @return true si la simulation est terminée, false sinon
     */
    public boolean estTerminee() {
        return estTerminee;
    }

    /**
     * Vérifie si le mouton est vainqueur.
     * @return true si le mouton a gagné, false si le loup a gagné ou si la simulation n'est pas terminée
     */
    public boolean estMoutonVainqueur() {
        return moutonVainqueur;
    }

    /**
     * Méthode originale pour jouer un tour (pour la compatibilité).
     * @param directionMouton La direction du mouton
     * @param directionLoup La direction du loup
     */
    public void jouerTour(Direction directionMouton, Direction directionLoup) {
        // Utiliser les vitesses maximales des animaux
        jouerTour(directionMouton, mouton.getVitesse(), directionLoup, loup.getVitesse());
    }

    /**
     * Méthode pour jouer un tour avec distance spécifiée pour le mouton.
     * @param directionMouton La direction du mouton
     * @param distanceMouton La distance à parcourir pour le mouton
     * @param directionLoup La direction du loup
     */
    public void jouerTour(Direction directionMouton, int distanceMouton, Direction directionLoup) {
        // Utiliser la vitesse maximale du loup
        jouerTour(directionMouton, distanceMouton, directionLoup, loup.getVitesse());
    }

    /**
     * Méthode pour jouer un tour avec distances spécifiées pour le mouton et le loup.
     * @param directionMouton La direction du mouton
     * @param distanceMouton La distance à parcourir pour le mouton
     * @param directionLoup La direction du loup
     * @param distanceLoup La distance à parcourir pour le loup
     */
    public void jouerTour(Direction directionMouton, int distanceMouton, Direction directionLoup, int distanceLoup) {
        if (estTerminee) {
            return;
        }

        // Vérifier si le mouton voit le loup
        if (mouton.peutVoir(loup.getPosition())) {
            mouton.setDetecteAdversaire(true);
        }

        // Vérifier si le loup voit le mouton
        if (loup.peutVoir(mouton.getPosition())) {
            loup.setDetecteAdversaire(true);
        }

        // Déplacer le mouton avec la distance spécifiée
        mouton.deplacer(directionMouton, distanceMouton, labyrinthe);

        // Vérifier si le mouton a atteint la sortie
        if (mouton.getPosition().equals(labyrinthe.getPositionSortie())) {
            estTerminee = true;
            moutonVainqueur = true;
            return;
        }

        // Déplacer le loup avec la distance spécifiée
        if (loup instanceof Loup) {
            // Utiliser la méthode deplacer avec distance pour le loup
            ((Loup) loup).deplacer(directionLoup, distanceLoup, labyrinthe);
        } else {
            // Fallback au cas où le loup n'est pas une instance de Loup
            loup.deplacer(directionLoup, labyrinthe);
        }

        // Vérifier si le loup a mangé le mouton
        if (loup.getPosition().equals(mouton.getPosition())) {
            estTerminee = true;
            moutonVainqueur = false;
            return;
        }

        nbTours++;
    }
}