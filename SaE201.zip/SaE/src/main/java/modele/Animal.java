package modele;

import java.io.Serializable;

public abstract class Animal implements Serializable {
    protected Position position;
    protected int vitesse;
    protected int vision;
    protected boolean detecteAdversaire;

    public Animal(Position position, int vitesse, int vision) {
        this.position = position;
        this.vitesse = vitesse;
        this.vision = vision;
        this.detecteAdversaire = false;
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    public int getVitesse() {
        return vitesse;
    }

    public void setVitesse(int vitesse) {
        this.vitesse = vitesse;
    }

    public int getVision() {
        return vision;
    }

    public boolean detecteAdversaire() {
        return detecteAdversaire;
    }

    public void setDetecteAdversaire(boolean detecte) {
        this.detecteAdversaire = detecte;
    }

    public boolean peutVoir(Position autre) {
        return position.distanceManhattan(autre) <= vision;
    }

    // Méthode pour vérifier si le mouvement est possible
    public abstract boolean peutSeDeplacer(Direction direction, Labyrinthe labyrinthe);

    // Méthode pour effectuer le déplacement
    public abstract void deplacer(Direction direction, Labyrinthe labyrinthe);
}