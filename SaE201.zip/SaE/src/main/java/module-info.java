module com.example.sae {
    requires javafx.controls;
    requires javafx.fxml;
    requires org.kordamp.bootstrapfx.core;

    exports com.example.sae;
    opens com.example.sae to javafx.fxml;

    exports modele;
    exports vue;
    exports controleur;
}